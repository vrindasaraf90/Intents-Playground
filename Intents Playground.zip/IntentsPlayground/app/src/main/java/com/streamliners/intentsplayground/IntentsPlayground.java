package com.streamliners.intentsplayground;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.streamliners.intentsplayground.databinding.ActivityIntentsPlaygroundBinding;

public class IntentsPlayground extends AppCompatActivity {

    ActivityIntentsPlaygroundBinding b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        b = ActivityIntentsPlaygroundBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        setTitle("Implicit Intents");
        setUpHideErrorForEdiText();
    }

    //Initial setup
    private void setUpHideErrorForEdiText() {
        b.outlinedTextField.getEditText().addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                hideError();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    //Event Handler
    public void OpenMainActivity(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void SendImplicitIntent(View view) {
        //validate input
        String input = b.outlinedTextField.getEditText().getText().toString().trim();
        if (input.isEmpty()){
            b.outlinedTextField.setError("Please enter something!");
            return;
        }

        //validate implicit type
        int type = b.RadioGrp.getCheckedRadioButtonId();

        //handle implicit intent
        if (type == R.id.OpenWebPage)
            openWebPage(input);
        else if (type ==  R.id.dialNum)
            dialNumber(input);
        else if (type == R.id.shareText)
            shareText(input);
        else
            Toast.makeText(this, "Please choose a intent type", Toast.LENGTH_SHORT).show();
    }


    //Implicit intent sender
    private void shareText(String text) {
        Intent intent = new Intent(); intent.setAction(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, text );
        startActivity(Intent.createChooser(intent, "Share text via"));
    }

    private void dialNumber(String number) {
        //check if input is Phone number
        if (!number.matches("^\\d{10}$")) {
            b.outlinedTextField.setError("Invalid NUMBER!");
            return;
        }

        Uri uri = Uri.parse("tel:" + number );
        Intent intent = new Intent(Intent.ACTION_DIAL, uri);
        startActivity(intent);

        hideError();
    }

    private void openWebPage(String url) {
        //check if input is URL
        if (!url.matches("^(http?|ftp|file)://[-a-zA-Z0-9+&@#/%?=~|!:,.;]*[-a-zA-Z0-9+&@#/%?=~_|]")) {
            b.outlinedTextField.setError("Invalid URL!");
            return;
        }

        Uri uri = Uri.parse(url);
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);

        hideError();
    }

    //Utility function
    private void hideError(){
        b.outlinedTextField.setError(null);
    }
}

